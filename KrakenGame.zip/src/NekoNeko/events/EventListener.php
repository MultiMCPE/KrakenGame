<?php

namespace NekoNeko\events;

use NekoNeko\Main;
use pocketmine\{event\Listener as Lis, tile\Sign, event\player\PlayerInteractEvent, event\player\PlayerMoveEvent, event\entity\EntityLevelChangeEvent, event\entity\EntityTeleportEvent, event\player\PlayerCommandPreprocessEvent, event\player\PlayerQuitEvent, Player, math\Vector3};

class EventListener implements Lis {
	public $plugin;
	
	public function __construct(Main $plugin) {
		$this->plugin = $plugin;
	}

    /**
     * @return Main
     */
	public function getPlugin() : Main {
		return $this->plugin;
	}
	
	public function BlockInteract(PlayerInteractEvent $e) {
	    $p = $e->getPlayer();
	    
	    if ($e->getAction() == 1) {
	        if (isset($this->getPlugin()->click[mb_strtolower($p->getName())])) {
	            if (!$e->getBlock()->getLevel()->getTile(new Vector3(($x = $e->getBlock()->getX()), ($y = $e->getBlock()->getY()), ($z = $e->getBlock()->getZ()))) instanceof Sign) return $p->sendMessage("§7[§l§cSquidGame§r§7] §fОшибка. Кликните по табличке!");
	            $this->getPlugin()->settings->set("signPos", ["x" => $x, "y" => $y, "z" => $z, "level" => $e->getBlock()->getLevel()->getName()]);
	            $this->getPlugin()->settings->save();
	            
	            $p->sendMessage("§7[§l§cSquidGame§r§7] §fТабличка установлена!");
	            unset($this->getPlugin()->click[mb_strtolower($p->getName())]);
	            
	            return;
	        }
	        
	        if (!$e->getBlock()->getLevel()->getTile(new Vector3(($x = $e->getBlock()->getX()), ($y = $e->getBlock()->getY()), ($z = $e->getBlock()->getZ()))) instanceof Sign) return;
	        $settings = $this->getPlugin()->settings->get("signPos");
	        if (!$settings) return;
	        if ($settings["x"] == $x && $settings["y"] == $y && $settings["z"] == $z && $settings["level"] == $e->getBlock()->getLevel()->getName()) {
	            $this->getPlugin()->joinSquidGame($p);
	            return;
	        }
	    }
	}
	
	public function moveEvent(PlayerMoveEvent $e) {
	    $p = $e->getPlayer();
	    
	    if (isset($this->getPlugin()->squidPlayers[mb_strtolower($p->getName())])) {
	        if ($this->getPlugin()->game["game"] == "start") {
	            if ($this->getPlugin()->game["stop"]) {
	                $update = time() - $this->getPlugin()->game["update"];
	                
	                if ($update >= 2) {
	                    $p->sendMessage("§l§cВы проиграли!");
	                    $this->getPlugin()->quitSquidGame($p);
	                    return;
	                }
	            }
	        }
	        
	        if ($this->getPlugin()->checkXYZ($p->getX(), $p->getY(), $p->getZ())) {
	            $this->getPlugin()->winSquidGame($p);
	            return;
	        }
	    }
	}
	
	public function levelChangeEvent(EntityLevelChangeEvent $e) {
	    if (($p = $e->getEntity()) instanceof Player) {
	        if (isset($this->getPlugin()->squidPlayers[mb_strtolower($p->getName())])) {
	            $e->setCancelled();
	        }
	    }
	}
	
	public function teleportEvent(EntityTeleportEvent $e) {
	    if (($p = $e->getEntity()) instanceof Player) {
	        if (isset($this->getPlugin()->squidPlayers[mb_strtolower($p->getName())])) {
	            $e->setCancelled();
	        }
	    }
	}
	
	public function commandEvent(PlayerCommandPreprocessEvent $e){
	    if (isset($this->getPlugin()->squidPlayers[mb_strtolower($e->getPlayer()->getName())])) {
	        if ($e->getMessage()[0] == "/") {
	            $msg = explode(" ", $e->getMessage());
	            
	            if ($msg[0] == "/spawn") {
	                $this->getPlugin()->quitSquidGame($e->getPlayer());
	            }
	            
	            $e->setCancelled();
	        }
	    }
	}
	
	public function playerQuit(PlayerQuitEvent $e) {
	    $this->getPlugin()->quitSquidGame($e->getPlayer());
	}
}