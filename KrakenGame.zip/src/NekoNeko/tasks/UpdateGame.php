<?php

namespace NekoNeko\tasks;

use NekoNeko\Main;
use pocketmine\scheduler\Task;

class UpdateGame extends Task {
	public $plugin;
	
	public function __construct(Main $plugin) {
		$this->plugin = $plugin;
	}
	
    /**
     * @return Main
     */
	public function getPlugin() : Main {
		return $this->plugin;
	}
	
	public function onRun($tick) {
		$this->getPlugin()->onUpdate();
	}
}
