<?php
namespace NekoNeko;

use NekoNeko\tasks\UpdateGame; // Таск для обновления игры
use NekoNeko\utils\Utils; // Для получения скина куклы
use NekoNeko\events\EventListener; // Эвенты
use pocketmine\scheduler\CallbackTask;
use pocketmine\network\mcpe\protocol\MoveEntityPacket;
use pocketmine\{plugin\PluginBase as PB, command\Command, command\CommandSender, Player, utils\Config, entity\Entity, entity\Human, level\Position};

class Main extends PB {
    
    public $settings; // Кфг с настройками, где хранятся позиции
    public $click = []; // Для установки позиции таблички
    public $squidPlayers = []; // Массив с именами игроков, которые находятся в игре
    public $game = ["game" => "stopped", "time" => NULL, "end" => NULL, "players" => [], "update" => NULL, "updateEnd" => NULL, "stop" => false]; // Массив с настройкой текущей игры
    public $doll; // Та самая кукла)
    
    public function onEnable() {
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
        
        if (!is_dir($dir = $this->getDataFolder())) @mkdir($dir);
        $this->settings = new Config($dir . "Settings.yml", Config::YAML, ["MaxPlayers" => 20]);
        
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new UpdateGame($this), 20);
    }
    
    /**
     * @return string
     */
    public function getDollSkinData() : string {
	    $texture = '/resources/skin.png';
	    $texture = $this->getFile() . $texture;
	    
        return Utils::getSkinFromFile($texture);
    }
    
    /**
     * @return Human
     */
    public function spawnDoll() : Human {
        $pos = $this->settings->get("dollPos");
        $pos2 = $pos["position"];
        
        $x = $pos2["x"];
        $y = $pos2["y"];
        $z = $pos2["z"];
        
        $yaw = $pos["yaw"];
        $pitch = $pos["pitch"];
        
        $level = $this->getServer()->getLevelByName($pos2["level"]);
        
        $nbt = new \pocketmine\nbt\tag\CompoundTag();
        $nbt->Pos = new \pocketmine\nbt\tag\ListTag("Pos", [
            new \pocketmine\nbt\tag\DoubleTag("", $x),
            new \pocketmine\nbt\tag\DoubleTag("", $y),
            new \pocketmine\nbt\tag\DoubleTag("", $z)
        ]);
        $nbt->Rotation = new \pocketmine\nbt\tag\ListTag("Rotation", [
            new \pocketmine\nbt\tag\FloatTag("", $yaw),
            new \pocketmine\nbt\tag\FloatTag("", $pitch)
        ]);
        
        $doll = new Human($level, $nbt);
        $doll->setSkin($this->getDollSkinData(), "Standard_Custom");
        
        $doll->spawnToAll();
        $doll->setDataProperty(Entity::DATA_SCALE, Entity::DATA_TYPE_FLOAT, 3);
        
        return $doll;
    }
    
    /**
     * @param int $stop
     * @return void
     */
    public function moveDoll(int $stop) : void {
        $yaw = 0;
        $pitch = 0;
        
        if ($stop) {
            $pos = $this->settings->get("dollPos");
            
            $yaw = $pos["yaw"];
            $pitch = $pos["pitch"];
        } else {
            $pos = $this->settings->get("turn");
            
            $yaw = $pos["yaw"];
            $pitch = $pos["pitch"];
        }
        
        $pk = new MoveEntityPacket();
        $pk->eid = $this->doll->getId();
        $pk->x = $this->doll->getX();
        $pk->y = $this->doll->getY();
        $pk->z = $this->doll->getZ();
        $pk->yaw = $yaw;
        $pk->pitch = $pitch;
        $pk->headYaw = $yaw;
        
        foreach ($this->doll->getViewers() as $viewer) {
            $viewer->dataPacket($pk);
        }
    }
    
    /**
     * @param CommandSender $p
     * @param Command $cmd
     * @param string $label
     * @param array $args
     */
    public function onCommand(CommandSender $p, Command $cmd, $label, array $args) {
        switch ($cmd) {
            case "kraken":
                if (!$p instanceof Player) {
                    $p->sendMessage("§7[§l§cSquidGame§r§7] §fИспользуй команду в игре!");
                    break;
                }
                
                if (!$p->isOp()) {
                    break;
                }
                
                if (!isset($args[0])) {
                    $this->sendSquidHelp($p);
                    break;
                }
                
                switch (mb_strtolower($args[0])) {
                    case "startpos":
                        $this->settings->set("playerPos", ["position" => ["x" => $p->getX(), "y" => $p->getY(), "z" => $p->getZ(), "level" => $p->getLevel()->getName()], "yaw" => $p->getYaw(), "pitch" => $p->getPitch()]);
                        $this->settings->save();
                        $p->sendMessage("§7[§l§cSquidGame§r§7] §fПозиция спавна игрока установлена!");
                        break;
                    case "dollpos":
                        $this->settings->set("dollPos", ["position" => ["x" => $p->getX(), "y" => $p->getY(), "z" => $p->getZ(), "level" => $p->getLevel()->getName()], "yaw" => $p->getYaw(), "pitch" => $p->getPitch()]);
                        $this->settings->save();
                        $p->sendMessage("§7[§l§cSquidGame§r§7] §fПозиция куклы установлена!");
                        break;
                    case "sign":
                        $this->click[mb_strtolower($p->getName())] = true;
                        $p->sendMessage("§7[§l§cSquidGame§r§7] §fКликните по табличке, чтобы установить ее позицию!");
                        break;
                    case "turn":
                        $this->settings->set("turn", ["yaw" => $p->getYaw(), "pitch" => $p->getPitch()]);
                        $this->settings->save();
                        $p->sendMessage("§7[§l§cSquidGame§r§7] §fВы установили точку заднего поворота куклы!");
                        break;
                    case "pos1":
                    case "pos2":
                        $this->settings->set(mb_strtolower($args[0]), ["x" => $p->getX(), "z" => $p->getZ()]);
                        $this->settings->save();
                        $p->sendMessage("§7[§l§cSquidGame§r§7] §fПозиция §b" . (mb_strtolower($args[0]) == "pos1" ? "1" : "2") . " §fустановлена.");
                        break;
                    default:
                        $this->sendSquidHelp($p);
                        break;
                }
                
                break;
        }
    }
    
    /**
     * @param Player $p
     */
    public function joinSquidGame(Player $p) {
        if (isset($this->squidPlayers[mb_strtolower($p->getName())])) return $p->sendMessage("§7[§l§cSquidGame§r§7] §fВы уже находитесь в игре!");
        if (count($this->game["players"]) >= $this->settings->get("MaxPlayers")) return $p->sendMessage("§7[§l§cSquidGame§r§7] §fИгра заполнена!");
        if ($this->game["game"] == "start") return $p->sendMessage("§7[§l§cSquidGame§r§7] §fИгра уже началась.");
        
        if (!$this->settings->get("dollPos")) return $p->sendMessage("§7[§l§cSquidGame§r§7] §fНе установлена позиция куклы!");
        if (!$this->settings->get("pos1")) return $p->sendMessage("§7[§l§cSquidGame§r§7] §fНе установлена 1 позиция конца игры!");
        if (!$this->settings->get("pos2")) return $p->sendMessage("§7[§l§cSquidGame§r§7] §fНе установлена 2 позиция конца игры!");
        if (!$this->settings->get("turn")) return $p->sendMessage("§7[§l§cSquidGame§r§7] §fНе установлена точка заднего поворота куклы!");
        
        $pos = $this->settings->get("playerPos");
        if (!$pos) return $p->sendMessage("§7[§l§cSquidGame§r§7] §fНе установлена позиция игрока!");
        $pos2 = $pos["position"];
        $p->teleport(new Position($pos2["x"], $pos2["y"], $pos2["z"], $this->getServer()->getLevelByName($pos2["level"])), $pos["yaw"], $pos["pitch"]);
        
        $this->game["players"][count($this->game["players"])] = mb_strtolower($p->getName());
        $this->squidPlayers[mb_strtolower($p->getName())] = true;
        
        $p->setGamemode(0);
        $p->setAllowFlight(false);
        $p->setImmobile(true);
        
        foreach ($this->game["players"] as $key => $value) {
            $pl = $this->getServer()->getOfflinePlayer($value);
            
            if ($pl->isOnline()) {
                $pl->sendMessage("§7[§l§cSquidGame§r§7] §b" . $p->getName() . " §fприсоединился к игре!");
            }
        }
        
        $this->game["game"] = "wait";
        
        $p->sendMessage("  §7* §fДля выхода с мини-игры введи §l§e/spawn§r§f");
    }
    
    /**
     * @param Player $p
     * @return void
     */
    public function quitSquidGame(Player $p) : void {
        unset($this->squidPlayers[$name = mb_strtolower($p->getName())]);
        
        foreach ($this->game["players"] as $key => $value) {
            if ($value == $name) {
                unset($this->game["players"][$key]);
            }
        }
        
        if (count($this->game["players"]) <= 0) {
            $this->game = ["game" => "stopped", "time" => NULL, "end" => NULL, "players" => [], "update" => NULL, "updateEnd" => NULL, "stop" => false];
            
            if (!is_null($this->doll)) {
                $this->doll->close();
                $this->doll = NULL;
            }
        }
        
        $p->setImmobile(false);
        
        $p->teleport($this->getServer()->getDefaultLevel()->getSpawnLocation());
    }
    
    /**
     * @param Player $p
     * @return void
     */
    public function winSquidGame(Player $p) : void {
        $rand = mt_rand(200, 400);
        $p->sendMessage("§l§aВы успешно перешли черту и выиграли игру! +" . $rand . "$");
        if (($eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI")) !== NULL) $eco->addMoney($p, $rand);
        $this->quitSquidGame($p);
    }
    
    /**
     * @return void
     */
    public function onUpdate() : void {
        switch ($this->game["game"]) {
            case "wait":
                if (is_null($this->game["time"])) {
                    $this->game["time"] = time() - 0;
                    break;
                }
                
                $start = 60 - (time() - $this->game["time"]);
                if ($start <= 0) {
                    $this->game["game"] = "start";
                    $this->game["end"] = time() - 0;
                    $this->game["update"] = time() - 0;
                    $this->game["updateEnd"] = mt_rand(3, 5);
                    
                    $this->doll = $this->spawnDoll();
                    
                    foreach ($this->game["players"] as $key => $value) {
                        $pl = $this->getServer()->getOfflinePlayer($value);
                        
                        if ($pl->isOnline()) {
                            $pl->setImmobile(false);
                            $pl->sendMessage("§7[§l§cSquidGame§r§7] §fИгра началась! Чтобы выиграть, вам нужно добраться до §l§cкрасной линии§f.\n §l§7* §fКогда §dкукла §fсмотрит на вас, вы не должны двигаться, иначе умрёте.");
                        }
                    }
                    
                    break;
                }
                
                foreach ($this->game["players"] as $key => $value) {
                    $pl = $this->getServer()->getOfflinePlayer($value);
                    
                    if ($pl->isOnline()) {
                        $pl->sendTip("§c-*- §l§fДо начала игры: §a" . $start . " §fсек. §c-*-");
                    }
                }
                
                break;
            case "start":
                $start = 120 - (time() - $this->game["end"]);
                $update = time() - $this->game["update"];
                
                foreach ($this->game["players"] as $key => $value) {
                    $pl = $this->getServer()->getOfflinePlayer($value);
                    
                    if ($pl->isOnline()) {
                        if ($start <= 0) {
                            $this->quitSquidGame($pl);
                            $pl->sendMessage("Вы проиграли! Игровое время закончилось");
                        } else {
                            $pl->sendTip("§7-*- §l§fДо конца игры осталось: §c" . $this->translateTime($start) . " §r§7-*-");
                            
                            if ($update > $this->game["updateEnd"]) {
                                $this->game["stop"] = $this->game["stop"] ? false : true;
                                
                                $this->moveDoll($this->game["stop"]);
                                
                                $pl->sendMessage($this->game["stop"] ? "§l§cЗамрите" : "§l§aВы можете двигаться!");
                                
                                $this->game["update"] = time() - 0;
                                $this->game["updateEnd"] = mt_rand(3, 5);
                            }
                        }
                    }
                }
                
                break;
        }
    }
    
    /**
     * @param Player $p
     * @return void
     */
    public function sendSquidHelp(Player $p) : void {
        $p->sendMessage("§7[§l§cSquidGame§r§7] §fПомощь:\n §7* §b/kraken startpos §7- §fУстановить точку появления игрока\n §7* §b/kraken dollpos §7- §fУстановить позицию куклы\n §7* §b/kraken sign §7- §fУстановить позицию таблички для входа в игру\n §7* §b/kraken turn §7- §fУстановить точку поворота для куклы, когда она будет смотреть назад\n §7* §b/kraken pos1/pos2 §7- §fУстановить 1/2 линию конца игры (высоту можно не выделять)\n\n\n §7* §fКогда вы устанавливаете точку спавна игрока/куклы, то учтите, что игрок/кукла будет спавниться смотря в ту точку, в которую смотрели вы.");
    }
    
    /**
     * @param int $time
     * @return string
     */
    public function translateTime(int $time) : string {
        $seconds = $time % 60;
        if ($seconds < 10) $seconds = "0" . $seconds;
        
        $minutes = (int) ($time / 60);
        
        return "0" . $minutes . ":" . $seconds;
    }
    
    /**
     * @param int $x
     * @param int $y
     * @param int $z
     * @return bool
     */
    public function checkXYZ(int $x, int $y, int $z) : bool {
        $pos1 = $this->settings->get("pos1");
        $pos2 = $this->settings->get("pos2");
        
		$minX = min($pos1["x"], $pos2["x"]);
		$maxX = max($pos1["x"], $pos2["x"]);
		
		$minZ = min($pos1["z"], $pos2["z"]);
		$maxZ = max($pos1["z"], $pos2["z"]);
        
        if ($x >= $minX and $x <= $maxX) {
            if ($z >= $minZ and $z <= $maxZ) {
                return true;
            }
        }
        
        return false;
    }
}